﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Population
{

    public float mutationRate;
    public DNA[] population;
    List<DNA> matingPool = new List<DNA>();
    public string target = "cunt";
    public int generations;
    public int populationSize;

    public bool isFinished = false;
    private int perfectScore;

    public DNA bestChild;

    public Population(string p, float m, int num)
    {
        target = p;
        mutationRate = m;
        population = new DNA[num];

        for (int i = 0; i < population.Length; i++)
        {
            population[i] = new DNA(target.Length);
        }

        calcFitness();
        isFinished = false;
        generations = 0;
    }

    public void calcFitness()
    {
        //Debug.Log(target);
        for (int i = 0; i < population.Length; i++)
        {
            population[i].fitnessFunc(target);
        }
    }

    public static float Map(float value, float fromSource, float toSource, float fromTarget, float toTarget)
    {
        return (value - fromSource) / (toSource - fromSource) * (toTarget - fromTarget) + fromTarget;
    }

    public void naturalSelection()
    {
        matingPool.Clear();

        float maxFitness = 0;
        for (int i = 0; i < population.Length; i++)
        {
            if (population[i].fitness > maxFitness)
            {
                maxFitness = population[i].fitness;
            }
        }

        for (int i = 0; i < population.Length; i++)
        {
            float fitness = Map(population[i].fitness, 0, maxFitness, 0, 1);
            int multiplier = (int)fitness * 100;
            for (int j = 0; j < multiplier; j++)
            {
                matingPool.Add(population[i]);
            }
        }
        // sort pop
        float temp;
        for (int i = 0; i <= population.Length-2; i++)
        {
            for (int j = 0; j <= population.Length-2; j++)
            {
                if(population[i].fitness > population[i + 1].fitness)
                {
                    temp = population[i + 1].fitness;
                    population[i + 1].fitness = population[i].fitness;
                    population[i].fitness = temp;
                }
            }
        }
        // prioritise certain DNA depending on fitness
        // add top 20 to mating pool
        /*
        for (int i = 0; i < (int)(population.Length*0.1); i++)
        {
            int fitnessMultiplier = (int)population[i].fitness*10;
            for (int j = 0; j < fitnessMultiplier+1; j++)
            {
                matingPool.Add(population[i]);
            }
        }*/
        /*
        // prioritise certain DNA depending on fitness
        // add bottom 5 to mating pool
        for (int i = population.Length-1; i > (int)(population.Length * 0.02)-1; i--)
        {
            int fitnessMultiplier = (int)population[i].fitness * target.Length;
            for (int j = 0; j < fitnessMultiplier + 1; j++)
            {
                matingPool.Add(population[i]);
            }
        }*/

        // get best child NOT COMPLETE
        
        bestChild = population[0];
        //Debug.Log(bestChild.phrase);
        if (bestChild != null && bestChild.phrase.Trim() == target.Trim())
        {
            Debug.Log("FOUND:" + bestChild.phrase + "Generation:" + generations);
            isFinished = true;
        } 

        //matingPool.Add(bestChild);
    }

    public float averageFitness()
    {
        float totalFit = 0;
        for (int i = 0; i < population.Length; i++)
        {
            totalFit += population[i].fitness;
        }
        return totalFit / population.Length;
    }

    public void generateNewPop()
    {
        // get the two children from each crossover
        for (int i = 0; i < population.Length/2; i+=2)
        {
            //gets 2 random parents
            int a = Random.Range(0, matingPool.Count);
            int b = Random.Range(0, matingPool.Count);

            while (b == a)
            {
                b = Random.Range(0, matingPool.Count);
            }

            DNA parentA = matingPool[a];
            DNA parentB = matingPool[b];
            DNA child = parentA.crossover(parentB);
            child.mutate(mutationRate);
            // Debug.Log(child1.phrase + child2.phrase);
            population[i] = child;
        }
        // increment gen num
        generations++;
    }


}
