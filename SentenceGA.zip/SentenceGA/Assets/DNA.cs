﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DNA
{

    public char[] sequence;
    public float fitness;

    private char[] alpha = "abcdefghijklmnopqrstuvwxyz ".ToCharArray();

    GeneticAlgorithm geneticAlgo
    {
        get
        {
            return GameObject.FindObjectOfType<GeneticAlgorithm>();
        }
    }

    private int sizeSeq;

    public string phrase
    {
        get
        {
            return new string(sequence);
        }
    }


    public DNA(int popSize)
    {
        sizeSeq = geneticAlgo.target.Length;
        sequence = new char[sizeSeq];
        for (int i = 0; i < sequence.Length; i++)
        {
            sequence[i] = alpha[Random.Range(0, alpha.Length)];
        }
    }

    public void fitnessFunc(string target)
    {
        int score = 0;
        for (int i = 0; i < sequence.Length; i++)
        {
            if (sequence[i] == target[i])
            {
                score++;
            }
        }

        fitness = (float)score / (float)target.Length;
    }
    
    /*public float fitnessFunc(string target)
    {
        string original = geneticAlgo.target;
        //Debug.Log(geneticAlgo.target);
        string gnome = phrase;

        float totalFitness = 0f;

        bool priorCorrect = false;
        for (int i = 0; i < original.Length; i++)
        {
            totalFitness += 26 - distanceBetween(original[i], gnome[i], "abcdefghijklmnopqrstuvwxyz ");

            if (original[i] == gnome[i] && priorCorrect == false)
            {
                totalFitness += 20;
                priorCorrect = true;
            }
            else if (original[i] == gnome[i] && priorCorrect == true)
            {
                totalFitness += 20;
                priorCorrect = true;
            }

            if (original[i] != gnome[i]) priorCorrect = false;


        }
        fitness = totalFitness;
        return totalFitness;
    }

    private int distanceBetween(char a, char b, string within)
    {

        int indexOfA = "abcdefghijklmnopqrstuvwxyz ".IndexOf(a);
        int indexOfB = "abcdefghijklmnopqrstuvwxyz ".IndexOf(b);

        int dist = Mathf.Abs(indexOfB - indexOfA);
        return dist;
    }*/

    public DNA crossover(DNA partner)
    {
        DNA child1 = new DNA(sequence.Length);
        int midPoint = (int)(Random.Range(0, sequence.Length));

        for (int i = 0; i < sequence.Length; i++)
        {
            if (i > midPoint)
            {
                child1.sequence[i] = sequence[i];
            } else
            {
                child1.sequence[i] = partner.sequence[i];
            }
        }

        return child1;
    }

    public void mutate(float mutationRate)
    {
        for (int i = 0; i < sequence.Length; i++)
        {
            if (Random.Range(0, 100) < mutationRate)
            {
                sequence[i] = alpha[Random.Range(0, alpha.Length)];
            }
        }
    }

}
