﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GeneticAlgorithm : MonoBehaviour
{
    public string target;
    public string currentBest;
    public int populationMax;
    public float mutationRate;

    public Text txt_targetSentence;
    public Text txt_currentSentence;

    Population p;
    GraphHelp h;

    float t;

    // Start is called before the first frame update
    void Start()
    {
        h = GameObject.FindObjectOfType<GraphHelp>();
        h.AddGraph("cunt", Color.red);
        p = new Population(target, mutationRate, populationMax);
        txt_targetSentence.text = target;
    }

    // Update is called once per frame
    void Update()
    {
        if (!p.isFinished)
        {
            t += Time.deltaTime;
            p.naturalSelection();
            p.generateNewPop();
            p.calcFitness();
            h.Plot(t, p.averageFitness(), 0);
            txt_currentSentence.text = p.bestChild.phrase.Trim();
        }
    }
}
